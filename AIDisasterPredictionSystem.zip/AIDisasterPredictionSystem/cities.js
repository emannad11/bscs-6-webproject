
const cities = [
    { name: 'Karachi', province: 'Sindh', population: 14910352 },
    { name: 'Lahore', province: 'Punjab', population: 11126285 },
    { name: 'Faisalabad', province: 'Punjab', population: 3204726 },
    { name: 'Rawalpindi', province: 'Punjab', population: 2098231 },
    { name: 'Gujranwala', province: 'Punjab', population: 2027001 },
    { name: 'Peshawar', province: 'Khyber Pakhtunkhwa', population: 1970042 },
    { name: 'Multan', province: 'Punjab', population: 1871843 },
    { name: 'Hyderabad', province: 'Sindh', population: 1734309 },
    { name: 'Islamabad', province: 'Federal Capital', population: 1014825 },
    { name: 'Quetta', province: 'Balochistan', population: 1001205 },
    { name: 'Bahawalpur', province: 'Punjab', population: 762111 },
    { name: 'Sargodha', province: 'Punjab', population: 659862 },
    { name: 'Sialkot', province: 'Punjab', population: 655852 },
    { name: 'Sukkur', province: 'Sindh', population: 499900 },
    { name: 'Larkana', province: 'Sindh', population: 490508 }
];

module.exports = cities;

