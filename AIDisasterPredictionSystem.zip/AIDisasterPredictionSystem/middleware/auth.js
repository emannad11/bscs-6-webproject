const jwt = require('jsonwebtoken');
const User = require('../models/User');

const authenticateToken = async (req, res, next) => {
    try {

        let token = req.cookies.token;
        
        if (!token) {
            const authHeader = req.headers.authorization;
            if (authHeader && authHeader.startsWith('Bearer ')) {
                token = authHeader.substring(7);
            }
        }

        if (!token) {
           
            if (req.headers.accept && req.headers.accept.includes('text/html')) {
                return res.redirect('/auth/login?message=Please login to access this page');
            }
           
            return res.status(401).json({ 
                error: 'Access denied. No token provided.',
                redirectTo: '/login'
            });
        }

        
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        const user = await User.findById(decoded.userId).select('-password');
        if (!user) {
            
            res.clearCookie('token');
            
            if (req.headers.accept && req.headers.accept.includes('text/html')) {
                return res.redirect('/auth/login?message=Session expired. Please login again');
            }
            return res.status(401).json({ 
                error: 'Invalid token. User not found.',
                redirectTo: '/login'
            });
        }

        req.user = user;
        next();
    } catch (error) {
        
        res.clearCookie('token');
        
        if (error.name === 'JsonWebTokenError') {
            if (req.headers.accept && req.headers.accept.includes('text/html')) {
                return res.redirect('/auth/login?message=Invalid session. Please login again');
            }
            return res.status(401).json({ 
                error: 'Invalid token.',
                redirectTo: '/login'
            });
        } else if (error.name === 'TokenExpiredError') {
            if (req.headers.accept && req.headers.accept.includes('text/html')) {
                return res.redirect('/auth/login?message=Session expired. Please login again');
            }
            return res.status(401).json({ 
                error: 'Token expired.',
                redirectTo: '/login'
            });
        }
        
        console.error('Auth middleware error:', error);
        if (req.headers.accept && req.headers.accept.includes('text/html')) {
            return res.redirect('/auth/login?message=Authentication error. Please try again');
        }
        return res.status(500).json({ error: 'Server error during authentication' });
    }
};

const redirectIfAuthenticated = (req, res, next) => {
    try {
       
        if (req.path === '/google/callback') {
            return next();
        }
        
        let token = req.cookies.token;
        
        if (!token) {
            const authHeader = req.headers.authorization;
            if (authHeader && authHeader.startsWith('Bearer ')) {
                token = authHeader.substring(7);
            }
        }

        if (token) {
            try {
                const decoded = jwt.verify(token, process.env.JWT_SECRET);
                if (decoded) {
                    console.log('User already authenticated, redirecting to dashboard');
                    return res.redirect('/dashboard');
                }
            } catch (tokenError) {
                
                res.clearCookie('token');
            }
        }
        
        next();
    } catch (error) {
       
        res.clearCookie('token');
        next();
    }
};


const authorize = (...roles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'Access denied. Please login.' });
        }

        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Access denied. Insufficient permissions.' });
        }

        next();
    };
};

module.exports = {
    authenticateToken,
    redirectIfAuthenticated,
    authorize
};

